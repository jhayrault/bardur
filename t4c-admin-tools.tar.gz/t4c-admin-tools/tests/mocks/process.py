import asyncio


class MockProcess:
    def __init__(self, stdout=b'', stderr=b'', return_code=0, hang=False):
        self._stdout = stdout
        self._stderr = stderr
        self.return_code = return_code
        self._hang = hang

    async def communicate(self):
        if self._hang:
            await asyncio.sleep(1)  # Simulate "pending"
        return self._stdout, self._stderr