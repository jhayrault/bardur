from t4c_admin_tools import __version__


def test_version():
    assert __version__ == '0.1.0'
