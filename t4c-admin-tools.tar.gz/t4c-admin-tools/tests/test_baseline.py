import unittest

from t4c_admin_tools.adapters.cli.baseline import ImportProject

class TestBaselineImportProject(unittest.TestCase):

    def setUp(self):
        self.workspace="workspace"
        self.dump=f"{self.workspace}/dump.xml"
        self.data_path=f"{self.workspace}/importer-workspace"
        self.repository="repoCapella"
        self.import_project = ("capellac --launcher.suppressErrors -nosplash -console -consoleLog " +
        "-data importer-workspace -application com.thalesgroup.mde.melody.collab.importer " +
        "-repositoryCredentials ../tools/repositoryCredentials.properties " +
        "-checksize -1 -closeserveronfailure false -stopRepositoryOnFailure false " +
        "-httpHost localhost -httpPort 8080 -httpPort 8080 -httpsConnection false -vmargs -Xms1000m -Xmx3000m -Xss4m " +
        "-XX:+UseG1GC -XX:+UseStringDeduplication -Dorg.eclipse.net4j.util.om.trace.disable=true -Dosgi.requiredJavaVersion=17 " +
        )








        -Dlogback.configurationFile=configuration/logback.xml
        -Dfr.obeo.dsl.viewpoint.collab.import.gmf.notation.keep.cdoid.as.xmiid=true
        -Dfr.obeo.dsl.viewpoint.collab.import.other.elements.keep.cdoid.as.xmiid=true
        -Dpde.jreProfile=JavaSE-17
        
        -data \"{self.data_path}\"
        -archiveProject true
        -outputFolder \"{self.workspace}\"
        -reponame {self.repository}
        -stopRepositoryOnFailure true
        -checksize 5
        -checkSession true
        -importCommitHistoryAsText true
        -includeCommitHistoryChanges false
        -computeImpactedRepresentationsForCommitHistoryChanges false
        -importFilePath \"{self.dump}\"
        -cdoExport true
        -archiveCdoExportResult true
        """

    def test_import_project_snapshot(self):
        # ARRANGE
        arrange = ImportProject(
            executable="cappelac",
            workspace_path=self.workspace,
            repository_name=self.repository
        )
        # ACT
        act: str = arrange.build()

        # ASSERT
        self.assertEqual(act, self.import_project)




if __name__ == '__main__':
    unittest.main()
