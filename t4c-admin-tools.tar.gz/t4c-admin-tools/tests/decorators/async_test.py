import asyncio
from typing import Any, Dict, Tuple

from t4c_admin_tools.adapters.cli.locking import Session


def async_test(f: Any) -> Any:
    def wrapper(*args: Tuple[Any], **kwargs: Dict[Any, Any]) -> Any:
        loop = asyncio.get_event_loop()
        return loop.run_until_complete(f(*args, **kwargs))
    return wrapper

def session(f: Any):
    def wrapper(*args: Tuple[Any], **kwargs: Dict[Any, Any]) -> Any:
        with Session() as session:
            f(session=session, *args, **kwargs)
    return wrapper