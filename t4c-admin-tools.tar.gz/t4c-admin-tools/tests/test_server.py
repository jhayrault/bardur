
class TestServerScript(unittest.TestCase):

    @patch('importer_script.subprocess.run')
    def test_run_command_lockinfo_script(self, mock_run):
        mock_run.return_value = MagicMock()

        tools_path = self.test_dir
        workspace = self.test_dir
        capella_home = self.test_dir
        repo_name = "repoX"

        from importer_script import run_command_lockinfo_script
        run_command_lockinfo_script(tools_path, workspace, capella_home, repo_name)

        mock_run.assert_called_once()
        called_args = mock_run.call_args[0][0]

        self.assertIn('-command', called_args)
        self.assertIn('cdo', called_args)
        self.assertIn('-commandParams', called_args)
        self.assertIn(f'lockinfo,{repo_name}', called_args)

    @patch('importer_script.subprocess.run')
    def test_run_tools_credentials_script(self, mock_run):
        mock_run.return_value = MagicMock()

        workspace = self.test_dir
        capella_home = self.test_dir
        command_type = "create"
        login = "admin"
        password = "secret"
        token_id = "abc123"

        from importer_script import run_tools_credentials_script
        run_tools_credentials_script(workspace, capella_home, command_type, login, password, token_id)

        mock_run.assert_called_once()
        called_args = mock_run.call_args[0][0]

        self.assertIn('-restAdmin', called_args)
        self.assertIn(command_type, called_args)
        self.assertIn('-login', called_args)
        self.assertIn(login, called_args)
        self.assertIn('-tokenSecretPath', called_args)
        self.assertTrue(any('userToken.txt' in arg for arg in called_args))

    @patch('importer_script.subprocess.run')
    def test_run_tools_credentials_create_user_script(self, mock_run):
        mock_run.return_value = MagicMock()

        workspace = self.test_dir
        capella_home = self.test_dir
        command_type = "createUser"
        login = "admin"
        password = "secret"
        user_id = "new_user"
        is_admin = True

        from importer_script import run_tools_credentials_create_user_script
        run_tools_credentials_create_user_script(
            workspace,
            capella_home,
            command_type,
            login,
            password,
            user_id,
            is_admin
        )

        mock_run.assert_called_once()
        called_args = mock_run.call_args[0][0]

        self.assertIn('-userId', called_args)
        self.assertIn(user_id, called_args)
        self.assertIn('-isAdmin', called_args)
        self.assertIn('true', called_args)
        self.assertIn('-tokenSecretPath', called_args)
        self.assertTrue(any('userToken.txt' in arg for arg in called_args))

    @patch('importer_script.subprocess.run')
    def test_run_tools_clear_credentials_script(self, mock_run):
        mock_run.return_value = MagicMock()

        workspace = self.test_dir
        capella_home = self.test_dir
        credential_type = "basic"
        hostname = "localhost"
        port = 1234
        repository_name = "repoX"

        from importer_script import run_tools_clear_credentials_script
        run_tools_clear_credentials_script(workspace, capella_home, credential_type, hostname, port, repository_name)

        mock_run.assert_called_once()
        called_args = mock_run.call_args[0][0]

        self.assertIn('-credentialType', called_args)
        self.assertIn(credential_type, called_args)
        self.assertIn('-hostname', called_args)
        self.assertIn(hostname, called_args)
        self.assertIn('-port', called_args)
        self.assertIn(str(port), called_args)
        self.assertIn('-reponame', called_args)
        self.assertIn(repository_name, called_args)
        self.assertIn('-clearStoredCredentials', called_args)
        self.assertIn('true', called_args)

    @patch('importer_script.subprocess.run')
    def test_run_tools_set_credentials_script(self, mock_run):
        mock_run.return_value = MagicMock()

        workspace = self.test_dir
        capella_home = self.test_dir
        credential_type = "basic"
        hostname = "localhost"
        port = 8080
        repository_name = "repoX"
        login = "admin"
        password = "secret"

        from importer_script import run_tools_set_credentials_script
        run_tools_set_credentials_script(workspace, capella_home, credential_type, hostname, port, repository_name,
                                         login, password)

        mock_run.assert_called_once()
        called_args = mock_run.call_args[0][0]

        self.assertIn('-credentialType', called_args)
        self.assertIn(credential_type, called_args)
        self.assertIn('-hostname', called_args)
        self.assertIn(hostname, called_args)
        self.assertIn('-port', called_args)
        self.assertIn(str(port), called_args)
        self.assertIn('-reponame', called_args)
        self.assertIn(repository_name, called_args)
        self.assertIn('-userId', called_args)
        self.assertIn(login, called_args)



