import unittest
import os
from pathlib import Path
import tempfile
from unittest.mock import patch, MagicMock
from importer_script import (
    run_command_stop_repository_script,
    delete_files_by_extension,
    remove_directory,
    run_importer_script,
    run_command_script,
    run_command_start_repository_script
)

class TestImporterScript(unittest.TestCase):

    @patch('importer_script.requests.post')
    def test_run_command_start_repository_script(self, mock_post):
        mock_response = MagicMock()
        mock_response.raise_for_status.return_value = None
        mock_post.return_value = mock_response

        tools_path = self.test_dir
        workspace = self.test_dir
        capella_home = self.test_dir
        repo_name = "repoX"

        run_command_start_repository_script(tools_path, workspace, capella_home, repo_name)

        mock_post.assert_called_once()
        called_url = mock_post.call_args[0][0]
        self.assertEqual(called_url, f"http://localhost:8080/api/v1.0/repositories/start/{repo_name}")

    @patch('importer_script.requests.post')
    def test_run_command_stop_repository_script(self, mock_post):
        mock_response = MagicMock()
        mock_response.raise_for_status.return_value = None
        mock_post.return_value = mock_response

        repo_name = "repoX"

        run_command_stop_repository_script(repo_name)

        mock_post.assert_called_once()
        called_url = mock_post.call_args[0][0]
        self.assertEqual(called_url, f"http://localhost:8080/api/v1.0/repositories/stop/{repo_name}")


