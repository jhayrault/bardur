from enum import Enum
from pathlib import Path
import sys

if sys.version_info >= (3, 8):
    from typing import  TypedDict, List, Union, Literal, Optional
else:
    from typing import  List, Union, Optional
    from typing_extensions import TypedDict, Literal

class CommandDict(TypedDict):
    arguments: List[str]
    base: str
    hash: str

class CommandResult(TypedDict):
    command: CommandDict
    message: str
    pid: Union[str, None]
    state: Literal["COMPLETED", "FAILED", "RUNNING"]


class Backup(TypedDict):
    output: CommandResult
    backup: Union[Path, str]

class Restoration(TypedDict):
    output: CommandResult
    restore: Union[Path, str]

class ConnectedProjectsAndLocks(TypedDict):
    connected_projects: List[str]
    locks: List[str]

class ActiveRepository(TypedDict):
    name: str
    status: str
    users: List[str]

ActiveRepositories = List[ActiveRepository]

class TokenEntry(TypedDict):
    token_id: str
    created_at: str
    expires_at: str
    status: Literal['active', 'revoked']


class TokenOperation(TypedDict, total=False):
    status: Literal['SUCCESS', 'FAILURE']
    message: str
    tokens: List[TokenEntry]


class RegisteredUser(TypedDict):
    user_id: str
    is_admin: bool
    created_at: str


class UserOperation(TypedDict, total=False):
    status: Literal['SUCCESS', 'FAILURE']
    message: str
    users: List[RegisteredUser]

class CredentialType(str, Enum):
    TOOLS_HTTP_CREDENTIALS = "TOOLS_HTTP_CREDENTIALS"
    TOOLS_REPOSITORY_CREDENTIALS = "TOOLS_REPOSITORY_CREDENTIALS"
    USER_REPOSITORY_CREDENTIALS = "USER_REPOSITORY_CREDENTIALS"

class ClearCredentials(TypedDict):
    status: Literal["SUCCESS", "FAILURE"]
    message: str

class StoreCredentials(TypedDict):
    status: Literal["SUCCESS", "FAILURE"]
    message: str

class StartRepository(TypedDict):
    status: Literal["STARTED", "ALREADY_RUNNING", "FAILED"]
    repository_name: str
    message: str

class StopRepository(TypedDict):
    status: Literal["STOPPED", "NOT_FOUND", "ERROR"]
    repository_name: str
    message: str

class ImportProject(TypedDict):
    status: Literal["SUCCESS", "FAILURE"]
    imported_projects: List[str]
    failed_projects: List[str]
    archive_path: Optional[str]
    message: Optional[str]

class RepositoryProjectsAtTimestamp(TypedDict):
    repository_name: str
    timestamp: str  # "HEAD" or "yyyy-MM-ddThh:mm:ss.SSSZ"
    projects: List[str]
    mode: Literal["HEAD", "TIMESTAMP"]

class RepositoryProjectDeletion(TypedDict):
    repository_name: str
    project_name: str
    success: bool
    message: str  # Status or error message

