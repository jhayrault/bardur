from pathlib import Path
from typing import List, Union

from t4c_admin_tools.domain.models import Backup


async def list_previous_backup(
        directory: Union[Path, str]
) -> List[Backup]:
    """
    Retrieve all previous backup files from the specified directory.

    Parameters:
        directory (Union[Path, str]): The directory to search for backup files.

    Returns:
        List[Path]: A list of paths representing the backup files found
        in the specified directory.
    """
    ...


async def delete_previous_backup(
        zip_files: List[Union[str, Path]]
) -> None:
    """
    Removes all provided backup files from the specified list or paths.

    Parameters:
        zip_files: List[str | Path]
            A list of file paths representing the backup files to be removed.
            Each path can either be a string or a Path object.

    Returns:
        None
    """

    ...

async def delete_files_of_projects(
        directory: Path,
        extensions: List[str] = ('.zip', '.txt', '.activitymetadata', '.json', '.xml')
) -> None:

    ...

async def delete_directory_of_project(directory: Path) -> None:

    ...