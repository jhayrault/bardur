import asyncio
import hashlib
import shlex
from abc import ABC, abstractmethod

from typing import Any, Dict, List, Tuple

from t4c_admin_tools.adapters.cli.locking import Mutex
from t4c_admin_tools.domain.models import CredentialType, CommandResult


async def run_command(
        command: List[str], 
        mutex: Mutex, 
        *args: Tuple[Any], 
        **kwargs: Dict[str, Any]
) -> CommandResult:
    
    command_base: str = " ".join(command)
    command_hash: str = hashlib.sha256(command_base.encode()).hexdigest()
    command_flags: List[str] = []
    for key, value in kwargs.items():
        key_flag = f"-{key.replace('_', '-')}"
        command_flags.extend([key_flag, str(value)])
    command_args: List[str] = command + [shlex.quote(str(a)) for a in args + tuple(command_flags)]

    command_full: str = " ".join(command_args)
    if mutex.is_locked(command_hash):
        return {
            "command": {
                "arguments": command_args,
                "base": command_full,
                "hash": command_hash
            },
            "state": "RUNNING",
            "pid": None,
            "message": "Command is going to run"
        }

    process = await asyncio.create_subprocess_shell(
        command_full,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE,
    )
    pid = process.pid

    locked = mutex.lock(command_hash, pid)
    if not locked:
        return {
            "command": {
                "arguments": command_args,
                "base": command_full,
                "hash": command_hash
            },
            "state": "RUNNING",
            "pid": None,
            "message": "Command is not released"
        }

    try:
        stdout, stderr = await process.communicate()
        if not stderr:
            return {
                "command": {
                    "arguments": command_args,
                    "base": command_full,
                    "hash": command_hash
                },
                "message": f"{stdout.decode()}",
                "pid": mutex.get_pid(command_hash),
                "state": "COMPLETED"
            }
        else:
            return {
                "command": {
                    "arguments": command_args,
                    "base": command_full,
                    "hash": command_hash
                },
                "message": f"{stderr.decode()}",
                "pid": mutex.get_pid(command_hash),
                "state": "FAILED"
            }
    except Exception as e:
        return {
            "command": {
                "arguments": command_args,
                "base": command_full,
                "hash": command_hash
            },
            "message": f"{type(e).__name__}: {e}",
            "pid": mutex.get_pid(command_hash),
            "state": "FAILED"
        }
    finally:
        mutex.unlock(command_hash)


class BaseCommand(ABC):

    #  cmd = RestoreCommand(executable="serverc.exe")
    #  cmd = BackupCommand(executable="capellac.exe")
    
    vm_args: List[str] = []
    java_version: str = "17"
    min_heap: str = "1000m"
    max_heap: str = "3000m"

    def __init__(self, executable: str):
        self.executable = executable
    
    @abstractmethod
    def get_args(self) -> List[str]:
        ...

    @abstractmethod
    def get_params(self) -> List[str]:
        ...

    def build(self) -> str:
        base_args = self.get_args()
        vm_args = self.vm_args + [
            f"-Xms{self.min_heap}",
            f"-Xmx{self.max_heap}",
            f"-Dosgi.requiredJavaVersion={self.java_version}"
        ]
        params = self.get_params()
        return " ".join([self.executable] + base_args + ["-vmargs"] + vm_args + params)


class RestoreBaseCommand(BaseCommand):
    ini_file: str = "server.ini"
    restore: bool = True
    restore_folder: str = "./restore"
    rename_source: bool = False
    config_dir: str = "configuration"


    def get_args(self) -> List[str]:
        return [
            f"--launcher.ini {self.ini_file}"
        ]

    @abstractmethod
    def get_params(self) -> List[str]:
        ...

    def __post_init__(self):
        super().__post_init__()
        self.vm_args.extend([
            "-XX:+UseG1GC",
            "-XX:+UseStringDeduplication",
            f"-Dcollab.db.restore={str(self.restore).lower()}",
            f"-Dcollab.db.restoreFolder=\"{self.restore_folder}\"",
            f"-Dcollab.db.restore.rename.source.file={str(self.rename_source).lower()}",
            f"-Dnet4j.config={self.config_dir}",
            "-Dnet4j.security.FileUserManager.fallBackToConfigFolder=true",
            "-Dcom.thalesgroup.mde.capella.team.close.server.after.initialization=true"
        ])


class HttpClientBaseCommand(BaseCommand):
    workspace_path: str
    http_host: str = "localhost"
    http_port: int = 8080
    https_connection: bool = False
    stack_size: str = "4m"
    log_config_path: str = 'configuration/logback.xml'

    def __init__(self, workspace_path: str, executable: str):
        super().__init__(executable)
        self.workspace_path = workspace_path

    def get_args(self) -> List[str]:
        return [
            "--launcher.suppressErrors",
            "-nosplash",
            "-console", "-consoleLog",
            "-data", self.workspace_path,
            "-httpHost", self.http_host,
            "-httpPort", str(self.http_port),
            "-httpsConnection", str(self.https_connection).lower(),
        ]

    @abstractmethod
    def get_params(self) -> List[str]:
        ...

    def __post_init__(self):
        self.vm_args.extend([
            f"-Xss{self.stack_size}",
            "-XX:+UseG1GC",
            "-XX:+UseStringDeduplication",
            "-Dorg.eclipse.net4j.util.om.trace.disable=true",
            f"-Dosgi.requiredJavaVersion={self.java_version}",
            "-Dosgi.dataAreaRequiresExplicitInit=true",
            f"-Dlogback.configurationFile={self.log_config_path}",
            f"-Dpde.jreProfile=JavaSE-{self.java_version}"
        ])


class LicenceClientBaseCommand(BaseCommand):
    workspace_path: str
    stack_size: str = "4m"
    log_config_path: str = 'configuration/logback.xml'

    def __init__(self, workspace_path: str, executable: str):
        super().__init__(executable)
        self.workspace_path = workspace_path


    def get_args(self) -> List[str]:
        return [
            "--launcher.suppressErrors",
            "-nosplash",
            "-console", "-consoleLog",
            "-data", self.workspace_path,
        ]

    @abstractmethod
    def get_params(self) -> List[str]:
        ...

    def __post_init__(self):
        self.vm_args.extend([
            f"-Xss{self.stack_size}",
            "-XX:+UseG1GC",
            "-XX:+UseStringDeduplication",
            "-Dorg.eclipse.net4j.util.om.trace.disable=true",
            f"-Dosgi.requiredJavaVersion={self.java_version}",
            "-Dosgi.dataAreaRequiresExplicitInit=true",
            f"-Dlogback.configurationFile={self.log_config_path}",
            f"-Dpde.jreProfile=JavaSE-{self.java_version}"
        ])


class ImportBaseCommand(HttpClientBaseCommand):
    data_workspace: str = "importer-workspace"
    repository_credentials_path: str = "../tools/repositoryCredentials.properties"

    def get_args(self) -> List[str]:
        return super().get_args() + [
            "-data", self.data_workspace,
            "-application com.thalesgroup.mde.melody.collab.importer"
            "-repositoryCredentials", self.repository_credentials_path,
            "-checksize -1",
            "-closeserveronfailure false",
            "-stopRepositoryOnFailure false"
        ]

    @abstractmethod
    def get_params(self) -> List[str]:
        ...

    def __post_init__(self):
        super().__post_init__()
        self.vm_args.extend([
            "-Dfr.obeo.dsl.viewpoint.collab.import.gmf.notation.keep.cdoid.as.xmiid=true",
            "-Dfr.obeo.dsl.viewpoint.collab.import.other.elements.keep.cdoid.as.xmiid=true"
        ])


class MaintenanceBaseCommand(HttpClientBaseCommand):
    data_workspace: str = "maintenance-workspace"
    repository_credentials_path: str = "../tools/repositoryCredentials.properties"

    def get_args(self) -> List[str]:
        return super().get_args() + [
            "-data", self.data_workspace,
            "-application com.thalesgroup.mde.melody.collab.maintenance"
            "-repositoryCredentials", self.repository_credentials_path
        ]

    @abstractmethod
    def get_params(self) -> List[str]:
        ...



class ToolCredentialBaseCommand(LicenceClientBaseCommand):

    def get_args(self) -> List[str]:
        return super().get_args() + [
            "-application", "fr.obeo.dsl.viewpoint.collab.tools.credentials"
        ]

    @abstractmethod
    def get_params(self) -> List[str]:
        ...


class Restore(RestoreBaseCommand):

    def get_params(self) -> List[str]:
        return []


class Backup(HttpClientBaseCommand):

    def get_args(self) -> List[str]:
        return super().get_args() + [
            "-application", "fr.obeo.dsl.viewpoint.collab.tools.command",
        ]

    def get_params(self) -> List[str]:
        return [
            "-data", f"\"{self.workspace_path}/command-workspace\"",
            "-command capella_db",
            f"-commandParams backup, \"{self.workspace_path}\""
        ]

class MaintenanceRepository(MaintenanceBaseCommand):

    def __init__(self, executable: str, repository_name: str, workspace_path: str):
        super().__init__(
            workspace_path=workspace_path,
            executable=executable
        )
        self.repository_name = repository_name


    def get_params(self) -> List[str]:
        return [
            "-repoName",  self.repository_name,
            "-data", f"\"{self.workspace_path}/maintenance-workspace\"",
            "-diagnosticOnly false",
            "-launchBackup true",
            "-archiveFolder", f"\"{self.workspace_path}\""
        ]


class StoreCredentials(ToolCredentialBaseCommand):
    host_name: str
    host_port: int
    repository_name: str
    login: str
    password: str
    credential_type: CredentialType
    
    def __init__(
            self,
            executable: str,
            workspace_path: str,
            host_name: str, 
            host_port: int, 
            repository_name: str, 
            login: str, 
            password: str,
            credential_type: CredentialType = CredentialType.TOOLS_HTTP_CREDENTIALS
    ) -> None:
        super().__init__(
            workspace_path=workspace_path,
            executable=executable
        )
        self.host_name = host_name
        self.host_port = host_port
        self.repository_name = repository_name
        self.login = login
        self.password = password
        self.credential_type = credential_type
    
    def get_params(self) -> List[str]:
        return [
            "-data", f"\"{self.workspace_path}/tools-workspace\"",
            "-credentialType", self.credential_type,
            "-hostname", self.host_name,
            "-port", str(self.host_port),
            "-reponame",  self.repository_name,
            "-userId", self.login,
            "-userPassword", self.password
        ]

class ToolsClearCredentials(ToolCredentialBaseCommand):
    host_name: str
    host_port: int
    repository_name: str
    login: str
    password: str
    credential_type: CredentialType

    def __init__(
            self,
            executable: str,
            workspace_path: str,
            host_name: str, 
            host_port: int, 
            repository_name: str, 
            login: str, 
            password: str,
            credential_type: CredentialType = CredentialType.TOOLS_HTTP_CREDENTIALS
    ) -> None:
        super().__init__(
            workspace_path=workspace_path,
            executable=executable
        )
        self.host_name = host_name
        self.host_port = host_port
        self.repository_name = repository_name
        self.login = login
        self.password = password
        self.credential_type = credential_type

    def get_params(self) -> List[str]:
        return [
            "-data", f"\"{self.workspace_path}/tools-workspace\"",
            "-credentialType", self.credential_type,
            "-hostname", self.host_name,
            "-port", str(self.host_port),
            "-reponame", self.repository_name,
            "-clearStoredCredentials true"
        ]


class ImportProject(ImportBaseCommand):
    repository_name: str
    import_file_path: str = "./dump.xml"

    def __init__(
            self,
            executable: str,
            workspace_path: str, 
            repository_name: str
    ) -> None:
        super().__init__(
            executable=executable,
            workspace_path=workspace_path
        )
        self.repository_name = repository_name

    def get_params(self) -> List[str]:
        return [
            "-data", f"\"{self.workspace_path}/importer-workspace\"",
            "-archiveProject true",
            "-outputFolder", self.workspace_path,
            "-reponame", self.repository_name,
            "-stopRepositoryOnFailure true",
            "-checksize 5",
            "-checkSession true",
            "-importCommitHistoryAsText true",
            "-includeCommitHistoryChanges false",
            "-computeImpactedRepresentationsForCommitHistoryChanges false",
             "-importFilePath", f"\"{self.workspace_path}/{self.import_file_path}\"",
            "-cdoExport true",
             "-archiveCdoExportResult true"
        ]