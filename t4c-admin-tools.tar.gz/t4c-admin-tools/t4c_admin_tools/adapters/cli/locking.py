import os.path
import platform
import tempfile
from multiprocessing.managers import SyncManager
from typing import Any

if platform.system() in ["Linux", "Darwin"]:
    import  fcntl
    UNIX = True
else:
    UNIX = False

class LockManager(SyncManager): pass

class Mutex:
    def __init__(self, manager: LockManager, lock_file_path: str = None):
        self._manager = manager
        self._manager.start()
        if not UNIX:
            raise NotImplementedError("fcntl-based locking is only supported on Unix-like systems.")

        self.file = None
        self.lock_file_path = lock_file_path
        self.locks = self._manager.dict()  # {command_hash: bool}
        self.pids = self._manager.dict()  # {command_hash: pid}

    def is_locked(self, cmd_hash: str):
        if self.lock_file_path is None:
            self.lock_file_path = os.path.join(tempfile.gettempdir(), cmd_hash)

        with open(self.lock_file_path, 'w') as lock_file:
            try:
                fcntl.flock(lock_file, fcntl.LOCK_EX | fcntl.LOCK_NB)
                fcntl.flock(lock_file, fcntl.LOCK_UN)
                return self.locks.get(cmd_hash, False)
            except BlockingIOError:
                return True

    def lock(self, cmd_hash: str, pid: int):
        if self.lock_file_path is None:
            self.lock_file_path = os.path.join(tempfile.gettempdir(), cmd_hash)
        self.file = open(self.lock_file_path, 'w')
        try:
            fcntl.flock(self.file, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            self.file.close()
            raise RuntimeError(f"Could not acquire lock on {self.lock_file_path}")

        if self.locks.get(cmd_hash, False):
            return False

        self.locks[cmd_hash] = self.file is not None
        self.pids[cmd_hash] = pid
        return True

    def unlock(self, cmd_hash: str):
        self.locks[cmd_hash] = False
        self.pids.pop(cmd_hash, None)
        if self.file:
            fcntl.flock(self.file, fcntl.LOCK_UN)
            self.file.close()
            try:
                os.remove(self.lock_file_path)
            except FileNotFoundError:
                pass

    def get_pid(self, cmd_hash: str):
        return self.pids.get(cmd_hash)

    def shutdown(self):
        self._manager.shutdown()


def start_session() -> Mutex:
    LockManager.register('Lock')
    m: LockManager = LockManager()
    return Mutex(m)


def stop_session(mutex: Mutex):
    mutex.shutdown()


class Session:
    def __init__(self):
        self.mutex = None

    def __enter__(self) -> Mutex:
        self.mutex = start_session()
        return self.mutex

    def __exit__(self, exc_type: Any, exc_val: Any, exc_tb: Any):
        if self.mutex:
            stop_session(self.mutex)
            self.mutex = None
