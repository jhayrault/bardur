import urllib.request
import urllib.error
import base64
import json
import asyncio
import ssl


class CustomHttpClient:
    def __init__(self, base_url, username=None, password=None, timeout=10, verify_ssl=True):
        self.base_url = base_url.rstrip('/')
        self.timeout = timeout
        self.headers = {
            'Accept': 'application/json',
            'User-Agent': 'HttpClientAdminTools/1.0'
        }
        self.username = username
        self.password = password
        self.verify_ssl = verify_ssl

        if username and password:
            auth_str = f'{username}:{password}'
            auth_bytes = auth_str.encode('utf-8')
            auth_b64 = base64.b64encode(auth_bytes).decode('utf-8')
            self.headers['Authorization'] = f'Basic {auth_b64}'

        self.ssl_context = ssl.create_default_context()
        if not verify_ssl:
            self.ssl_context.check_hostname = False
            self.ssl_context.verify_mode = ssl.CERT_NONE

    def _build_url(self, endpoint):
        if not endpoint.startswith('/'):
            endpoint = '/' + endpoint
        return self.base_url + endpoint

    async def _request(self, method, endpoint, data=None, extra_headers=None):
        url = self._build_url(endpoint)
        headers = self.headers.copy()

        if extra_headers:
            headers.update(extra_headers)

        if data is not None:
            if not isinstance(data, bytes):
                data = json.dumps(data).encode('utf-8')
            if 'Content-Type' not in headers:
                headers['Content-Type'] = 'application/json'

        try:
            request = urllib.request.Request(
                url,
                data=data,
                headers=headers,
                method=method
            )

            loop = asyncio.get_event_loop()
            response = await loop.run_in_executor(
                None,
                lambda: urllib.request.urlopen(
                    request,
                    timeout=self.timeout,
                    context=self.ssl_context
                )
            )

            content_type = response.headers.get('Content-Type', '')
            resp_data = await loop.run_in_executor(None, response.read)
            resp_text = resp_data.decode('utf-8')

            if 'application/json' in content_type:
                return json.loads(resp_text)
            return resp_text

        except urllib.error.HTTPError as e:
            print(f'HTTP Error {e.code} - {e.reason}')
            raise
        except urllib.error.URLError as e:
            print(f'URL Error: {str(e)}')
            raise
        except Exception as e:
            print(f'Error: {str(e)}')
            raise
    
    async def get(self, endpoint, extra_headers=None):
        return await self._request('GET', endpoint, extra_headers=extra_headers)
    
    async def post(self, endpoint, data, extra_headers=None):
        return await self._request('POST', endpoint, data, extra_headers=extra_headers)
    
    async def put(self, endpoint, data, extra_headers=None):
        return await self._request('PUT', endpoint, data, extra_headers=extra_headers)
    
    async def delete(self, endpoint, extra_headers=None):
        return await self._request('DELETE', endpoint, extra_headers=extra_headers)


async def list_projects_by_repository(client: CustomHttpClient, repository_name: str, checkout: str = 'HEAD'):
    return await client.get(f"/api/v1.0/projects/{repository_name}?checkout={checkout}")

async def stop_repository(client: CustomHttpClient, repository_name: str):
    return await client.get(f"/api/v1.0/repositories/stop/{repository_name}")

async def start_repository(client: CustomHttpClient, repository_name: str):
    return await client.get(f"/api/v1.0/repositories/start/{repository_name}")