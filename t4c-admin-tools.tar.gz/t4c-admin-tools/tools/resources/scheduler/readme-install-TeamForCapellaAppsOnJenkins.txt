You can install the Team for Capella application on Jenkins for a better management of your shared project.

You can either install it automatically using the script install-TeamForCapellaAppsOnJenkins.bat or manually.
See install-TeamForCapellaAppsOnJenkins.properties for script options.

For both methods, you should refer to the help section provided by Team for Capella under the category 
"Team for Capella Guide > System Administrator Guide > Jenkins installation" or the Jenkins installation PDF provided with the Team for Capella installation guide.

For both methods, you will have to execute the following manual steps: 
- Jenkins requires a global environment variable referencing the location of your team for Capella installation
  - Go to Manage Jenkins / Configure System and scroll down to the Global properties section.
  - Check Environment variables and add a new one named TEAMFORCAPELLA_APP_HOME
  - Set the value to the absolute path of your Team for Capella installation folder
    (it is the top folder that contains the subfolders "capella", "server", "tools"...).
  - Linux:
    - Make sure that the jenkins user has read, write and execution privilege on the Team for Capella installation folder.
    - Make sure that an Xvnc server is installed on the server (required for the server and importer application).
  
- We recommend to change the number of executors to 5:
  - By default Jenkins provides two build executors. This means that two applications can run at the same time. 
  - However, the CDO server and the License server are application that keeps running. Therefore, they will block any other application. 
  - For this, click on the "Build Executor Status" (Bottom left on the Jenkins Dashboard).
  - Then on the entry presenting the computer, click on the Configure button. 
  - On this executors configuration page, set the number of executors to 5.
- Change the Markup Formatter to display the jobs descriptions as HTML and not as plain text.
  - Go to Manage Jenkins / Configure Global Security and scroll down to the Markup Formatter section.
  - Change the value to Safe HTML.
- See additional possible settings in "Team for Capella Guide > System Administrator Guide > Jenkins installation > Miscellaneous settings".
- Restart Jenkins
