from datetime import datetime
from pathlib import Path
from typing import Union, Literal, Optional

from t4c_admin_tools.adapters.cli.baseline import ImportProject
from t4c_admin_tools.domain.models import (
    ActiveRepositories,
    Backup,
    ClearCredentials,
    ConnectedProjectsAndLocks,
    CredentialType,
    RepositoryProjectDeletion,
    RepositoryProjectsAtTimestamp,
    Restoration,
    StartRepository,
    StopRepository,
    StoreCredentials,
    TokenOperation,
    UserOperation
)
from t4c_admin_tools.main import Session


async def clear_secure_credentials(
        session: Session,
        credential_type: CredentialType,
        repository_name: Optional[str] = "repoCapella"
) -> ClearCredentials:
    """
    Clears credentials from Eclipse Secure Storage for REST Admin or CDO repository access.

    Args:
        session (Session): The current session object.
        credential_type (CredentialType): Type of credential to clear.
            One of: 'TOOLS_HTTP_CREDENTIALS', 'TOOLS_REPOSITORY_CREDENTIALS', 'USER_REPOSITORY_CREDENTIALS'.
        repository_name (Optional[str]): The name of the CDO repository. Required only
            for TOOLS_REPOSITORY_CREDENTIALS and USER_REPOSITORY_CREDENTIALS.

    Returns:
        ClearCredentials: A dictionary with the result of the operation.

    Raises:
        ValueError: If required fields are missing or misconfigured.
        ConnectionError: If the remote server is unreachable.
        RuntimeError: If the credential application fails to execute properly.
    """

    raise NotImplementedError("To be implemented in the infrastructure adapter.")


async def database_backup(
        session: Session,
        backup_folder: Union[Path, str]
) -> Backup:
    """
    Dump a database into a zip file and keep it as an artifact of the build.

    Args:
        session (Session): The current session object.
        backup_folder (Union[Path, str]): Destination path where the database backup zip file will be stored.

    Returns:
        Path: Path to the created zip file.

    """

    raise NotImplementedError("This use case must be implemented via an adapter.")


async def database_restore(
        session: Session,
        restore_folder: Union[Path, str]
) -> Restoration:
    """
    Restore the database from a previously backed-up database.

    Args:
        session: The current session object.
        restore_folder (Union[Path, str]): Path to the backup directory to restore from.

    Returns:
        Restoration: A Typed Dictionary containing the command line result and path to the restored database
    """

    raise NotImplementedError("This use case must be implemented via an adapter.")


def delete_project_from_repository(
        repository_name: str,
        project_name: str,
) -> RepositoryProjectDeletion:
    """
    Deletes a project from the specified repository using the exporter application.

    Args:
        repository_name (str): The name of the repository.
        project_name (str): The name of the project to delete.

    Returns:
        ProjectDeletionResult: Result of the deletion with status and message.

    Raises:
        FileNotFoundError: If the repository or project does not exist.
        RuntimeError: If the exporter application fails during deletion.
    """

    raise NotImplementedError("This function should be implemented by the infrastructure adapter")


def import_projects(
        repository_name: str,
        output_directory: str,
        import_strategy: Literal["snapshot", "connected"] = "snapshot",
        login: Optional[str] = None,
        password: Optional[str] = None,
        stop_on_failure: bool = True
) -> ImportProject:
    """
    Imports projects from a CDO repository using the configured importer application.


    Args:
        repository_name (str): The repository containing the projects.
        output_directory (str): Where to archive the imported projects.
        import_strategy (Literal): The import strategy ('snapshot' or 'connected').
        login (Optional[str]): Login for "connected" strategy.
        password (Optional[str]): Password for "connected" strategy.
        stop_on_failure (bool): Whether to close the repository if the import fails (default: True).

    Returns:
        ImportProject: Result of the import, including imported and failed projects.

    Raises:
        ValueError: If required parameters are invalid.
        RuntimeError: If the import process fails or returns an error.
    """
    raise NotImplementedError("To be implemented by an infrastructure adapter.")


async def list_active_repositories() -> ActiveRepositories:
    """
        Lists the currently active repositories on the Capella collaboration server.

        This function queries the server for active repositories and returns their
        names, current status, and connected users (if applicable). The list is
        intended to be consumed or logged by a calling adapter.

        Returns:
            ActiveRepositories: A list of currently active repositories.

        Raises:
            ValueError: If input parameters are invalid.
            ConnectionError: If the server is unreachable or times out.
            RuntimeError: If the server response is invalid or cannot be parsed.
        """
    raise NotImplementedError("This service must be implemented by an adapter.")


async def list_connected_projects_and_locks() -> ConnectedProjectsAndLocks:
    """
        Lists the opened Capella shared projects and currently locked objects.

        This function queries Capella collaboration server to:
          - List the opened shared Capella projects along with the usernames
            of the users who have opened them (i.e., active CDO sessions).
          - List the currently locked model elements, grouped by project and
            associated with the user who holds each lock.

        Returns:
            ConnectedProjectsAndLocks: A dictionary containing the list of active projects
            with users and locked objects grouped by project.

        Raises:
            ValueError: If the server URL or authentication token is invalid.
            ConnectionError: If the server cannot be reached.
            RuntimeError: If the server response is invalid or parsing fails.
        """

    raise NotImplementedError("This use case must be implemented via an adapter.")


def list_repository_projects(
        repository_name: str,
        checkout_timestamp: str = "HEAD"
) -> RepositoryProjectsAtTimestamp:
    """
       Lists the projects in a repository at the specified point in time.

       Args:
           repository_name (str): Name of the CDO repository.
           checkout_timestamp (str): Timestamp in ISO 8601 format (e.g., "2024-05-24T14:30:00.000+0000")
                                     or 'HEAD' for the latest state.

       Returns:
           RepositoryProjectsAtTimestamp: Dictionary of repository, timestamp, and project list.

       Raises:
           ValueError: If the timestamp format is invalid.
           RuntimeError: If the repository access fails.
       """
    if checkout_timestamp != "HEAD":
        try:
            datetime.strptime(checkout_timestamp, "%Y-%m-%dT%H:%M:%S.%f%z")
        except ValueError:
            raise ValueError("Timestamp must be 'HEAD' or ISO 8601 format.")

    raise NotImplementedError("Must be implemented by infrastructure adapter")


async def manage_registered_users(
        session: Session,
        command_type: Literal['listUsers', 'createUser', 'removeUser'],
        login: str = 'admin',
        password: str = '',
        is_admin: bool = False,
        user_id: str = ''
) -> UserOperation:
    """
    Manages registered users via the Tools Credentials Application for the REST API.

    This function performs one of the following operations:
      - 'listUsers': Lists all currently registered users.
      - 'createUser': Creates a new user account.
      - 'removeUser': Deletes an existing user account.

    Args:
        session (Session): The current session object.
        command_type (str): The command to execute. One of: 'listUsers',
            'createUser', or 'removeUser'.
        login (str): The administrator login (default is 'admin').
        password (str): An access token for the administrator account.
        is_admin (bool): Indicates whether the new user should have admin privileges.
            Only used for 'createUser'.
        user_id (str): The login ID of the user to create or remove.
            Not used for 'listUsers'.

    Returns:
        UserOperation: A dictionary indicating the result of the operation.
        Includes a list of users for the 'listUsers' command.

    Raises:
        ValueError: If required parameters are missing or misused.
        ConnectionError: If the REST API server is unreachable.
        RuntimeError: If the server responds with an unexpected or error result.
    """
    raise NotImplementedError("This service must be implemented by an adapter")


async def manage_user_token_credentials(
        command_type: Literal['listTokens', 'generate', 'regenerate', 'revoke'],
        login: str,
        password: str,
        token_id: str = None
) -> TokenOperation:
    """
        Manages user token credentials via the Tools Credentials Application.

        The supported commands are:
          - 'listTokens': Lists all tokens associated with the user.
          - 'generate': Generates a new token with the specified ID.
          - 'regenerate': Regenerates an existing token with the specified ID.
          - 'revoke': Revokes a token by its ID.

        Args:
            command_type (str): The command to execute. One of: 'listTokens',
                'generate', 'regenerate', 'revoke'.
            login (str): The user login. Must be a valid REST Admin API user.
            password (str): An access token associated with the user.
            token_id (str, optional): The ID of the token to act on. Required
                for all commands except 'listTokens'.

        Returns:
            TokenOperation: Result of the token operation, including status,
            optional message, and list of tokens (for 'listTokens').

        Raises:
            ValueError: If parameters are missing or inconsistent with the command.
            ConnectionError: If the REST API is unreachable.
            RuntimeError: If the API response is malformed or indicates failure.
        """
    raise NotImplementedError("This service must be implemented by an adapter.")


async def start_repository(
        repository_name: str,
) -> StartRepository:
    """
    Starts a repository on the specified CDO server.

    Args:
        repository_name (str): The name of the repository to start.

    Returns:
        StartRepository: Dictionary with status, repository name, and optional message.

    Raises:
        ConnectionError: If the server is not reachable.
        RuntimeError: If the repository could not be started.
        ValueError: If the repository name is invalid or empty.
    """
    raise NotImplementedError("This should be implemented by an infrastructure adapter.")


async def stop_repository(
        repository_name: str
) -> StopRepository:
    """
    Stops an active repository on the CDO server.

    Args:
        repository_name (str): Name of the repository to stop.

    Returns:
        StopRepository: Status result indicating an outcome.

    Raises:
        ValueError: If the repository name is invalid or empty.
        ConnectionError: If the server cannot be contacted.
        RuntimeError: If the stop command fails.
    """
    raise NotImplementedError("This should be implemented by an infrastructure adapter.")


async def store_secure_credentials(
        session: Session,
        credential_type: CredentialType,
        login: str,
        password: str,
        repository_name: Optional[str] = "repoCapella"
) -> StoreCredentials:
    """
    Stores credentials into Eclipse Secure Storage for either REST Admin API or CDO repository access.

    Args:
        session (Session): The current session object.
        credential_type (CredentialType): Type of credential to store.
        login (str): Username or token to be stored.
        password (str): Password or API token to be stored.
        repository_name (Optional[str]): Required for CDO credentials. The default is 'repoCapella'.

    Returns:
        StoreCredentials: Status and message of the operation.

    Raises:
        ValueError: If required values are missing for the selected credential type.
        PermissionError: If login/password authentication fails.
        RuntimeError: If the credential application encounters an error.
    """
    raise NotImplementedError("Adapter logic must implement this interface.")
