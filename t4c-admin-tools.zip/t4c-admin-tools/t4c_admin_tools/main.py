import asyncio
from email.policy import default
from getpass import getpass

from t4c_admin_tools.adapters.cli.locking import Session
from t4c_admin_tools.application.services import (
    clear_secure_credentials,
    store_secure_credentials,
    start_repository,
    stop_repository,
    manage_registered_users,
    database_restore,
    database_backup
)
import argparse

from t4c_admin_tools.domain.models import CredentialType


async def tadm_database_backup(args: argparse.Namespace):
    return await database_backup(
        session=args.session,
        backup_folder=args.folder
    )

async def tadm_database_restore(args: argparse.Namespace):
    return await database_restore(
        session=args.session,
        restore_folder=args.folder
    )

async def tadm_admin_users(args: argparse.Namespace):
    password = args.password or getpass(prompt='Enter password: ')
    match args.action:
        case 'list':
            return await manage_registered_users(
                session=args.session,
                command_type= 'listUsers',
                login=args.login,
                password=password
            )
        case 'create':
            return await manage_registered_users(
                session=args.session,
                command_type='createUser',
                login=args.login,
                password=args.password,
                is_admin=bool(args.profile == 'admin'),
                user_id=args.user
            )
        case 'remove':
            return await manage_registered_users(
                session=args.session,
                command_type='removeUser',
                login=args.login,
                password=args.password,
                user_id=args.user
            )
    return None

async def tadm_admin_credentials_store(args: argparse.Namespace):
    match args.type:
        case 'admin':
            return await store_secure_credentials(
                session=args.session,
                credential_type=CredentialType.TOOLS_HTTP_CREDENTIALS,
                login=args.login,
                password=args.password,
            )
        case 'repository':
            return await store_secure_credentials(
                session=args.session,
                credential_type=CredentialType.TOOLS_REPOSITORY_CREDENTIALS,
                login=args.login,
                password=args.password,
                repository_name=args.repository
            )
        case 'other':
            return await store_secure_credentials(
                session=args.session,
                credential_type=CredentialType.USER_REPOSITORY_CREDENTIALS,
                login=args.login,
                password=args.password,
                repository_name=args.repository
            )
    return None

async def tadm_admin_credentials_clear(args: argparse.Namespace):
    match args.type:
        case 'admin':
            return await clear_secure_credentials(
                session=args.session,
                credential_type=CredentialType.TOOLS_HTTP_CREDENTIALS,

            )
        case 'repository':
            return await clear_secure_credentials(
                session=args.session,
                credential_type=CredentialType.TOOLS_REPOSITORY_CREDENTIALS,
                repository_name=args.repository
            )
        case 'other':
            return await clear_secure_credentials(
                session=args.session,
                credential_type=CredentialType.USER_REPOSITORY_CREDENTIALS,
                repository_name=args.repository
            )
    return None



def parse_args(s: Session):
    parser = argparse.ArgumentParser(prog='tadm')

    subparsers = parser.add_subparsers(dest='command')

    # tadm database
    db_parser = subparsers.add_parser('database')
    db_subparsers = db_parser.add_subparsers(dest='db_command')
    ## tadm database backup
    backup_parser = db_subparsers.add_parser('backup')
    backup_parser.add_argument('--folder', '-f', required=True)
    backup_parser.set_defaults(func=tadm_database_backup, session=s)
    ## tadm database restore
    restore_parser = db_subparsers.add_parser('restore')
    restore_parser.add_argument('--folder', '-f', required=True)
    restore_parser.set_defaults(func=tadm_database_restore, session=s)

    # tadm admin
    manage_parser = subparsers.add_parser('admin')
    manage_subparsers = manage_parser.add_subparsers(dest='admin_command')
    ## tadm admin user
    user_parser = manage_subparsers.add_parser('user')
    user_parser.add_argument(
        'action',
        help='Action to perform. Possible values: list, create, remove',
        choices=['list', 'create', 'remove']
    )
    user_parser.add_argument(
        '--login', '-l',
        help='admin login. Required for "create" and "remove" actions.'
    )
    user_parser.add_argument('--password', '-l', help='admin password')
    user_parser.add_argument('--user', '-u', help='User name')
    user_parser.add_argument('--profile', choices=['admin', 'user'], default='user')
    user_parser.set_defaults(func=tadm_admin_users)
    ## tadm admin credentials
    token_parser = manage_subparsers.add_parser('credentials')
    token_subparsers = token_parser.add_subparsers(dest='token_command')

    ### tadm admin credentials generate
    credentials_generate_parser = token_subparsers.add_parser('generate')
    credentials_generate_parser.add_argument(
        '--type', '-t',
        help='Credential type. Possible values: admin, repository, other. Default: other',
        choices=['admin', 'repository', 'other'],
        default='other'
    )
    credentials_generate_parser.add_argument(
        '--login', '-l',
        help='admin login. Required for "generate" action.',
        required=True
    )
    credentials_generate_parser.add_argument(
        '--password', '-p',
        help='admin password. Required for "generate" action (will prompt if not provided)',
        required=True
    )
    credentials_generate_parser.add_argument(
        '--repository', '-r',
        help='repository name. Required for "repository" and "other" type. Default: repoCapella',
        default='repoCapella'
    )
    credentials_generate_parser.set_defaults(func=tadm_admin_credentials_store)

    ### tadm admin credentials revoke
    credentials_revoke_parser = token_subparsers.add_parser('revoke')
    credentials_revoke_parser.add_argument(
        '--type', '-t',
        help='Credential type. Possible values: admin, repository, other. Default: other',
        choices=['admin', 'repository', 'other'],
        default='other'
    )
    credentials_revoke_parser.add_argument('--repository', '-r', help='Repository name')
    credentials_revoke_parser.set_defaults(func=tadm_admin_credentials_store)

    # tadm repository
    repository_parser = subparsers.add_parser('repository')
    repository_subparsers = repository_parser.add_subparsers(dest='repository_command')

    ## tadm repository start
    repository_start_parser = repository_subparsers.add_parser('start')
    repository_start_parser.add_argument('--repository', '-r', help='Repository name')
    repository_start_parser.set_defaults(func=start_repository)

    ## tadm repository stop
    repository_stop_parser = repository_subparsers.add_parser('stop')
    repository_stop_parser.add_argument('--repository', '-r', help='Repository name')
    repository_stop_parser.set_defaults(func=stop_repository)

    return parser

async def main(s: Session):
    parser = parse_args(s)
    args = parser.parse_args()
    if hasattr(args, 'func'):
        await args.func(args)
    else:
        parser.print_help()

if __name__ == '__main__':
    with Session() as session:
        asyncio.run(main(session))