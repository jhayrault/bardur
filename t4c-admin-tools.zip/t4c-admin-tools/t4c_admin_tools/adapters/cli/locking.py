from multiprocessing.managers import SyncManager, BaseManager


class Mutex:
    def __init__(self, manager):
        self.start()
        self.locks = manager.dict()  # {command_hash: bool}
        self.pids = manager.dict()  # {command_hash: pid}
        self._manager = manager

    def is_locked(self, cmd_hash):
        return self.locks.get(cmd_hash, False)

    def lock(self, cmd_hash, pid):
        if self.locks.get(cmd_hash, False):
            return False
        self.locks[cmd_hash] = True
        self.pids[cmd_hash] = pid
        return True

    def unlock(self, cmd_hash):
        self.locks[cmd_hash] = False
        self.pids.pop(cmd_hash, None)

    def get_pid(self, cmd_hash):
        return self.pids.get(cmd_hash)

    def shutdown(self):
        if self._manager.is_alive():
            self._manager.shutdown()

    def start(self):
        if not self._manager.is_alive():
            self._manager.start()


class LockManager(SyncManager): pass

def start_session():
    LockManager.register('Lock')
    m: LockManager = LockManager()
    return Mutex(m)

def stop_session(mutex):
    mutex.shutdown()

class Session:
    def __init__(self):
        self.mutex = None

    def __enter__(self):
        self.mutex = start_session()
        return self.mutex

    def __exit__(self, exc_type, exc_val, exc_tb):
        if self.mutex:
            stop_session(self.mutex)
            self.mutex = None