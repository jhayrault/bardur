import asyncio
import hashlib
import shlex
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import List

from t4c_admin_tools.domain.models import CredentialType, CommandResult


async def run_command(command: List[str], mutex: Mutex = lambda: create_mutex, *args, **kwargs) -> CommandResult:
    command_base = " ".join(command)
    command_hash = hashlib.sha256(command_base.encode()).hexdigest()
    command_flags = []
    for key, value in kwargs.items():
        key_flag = f"-{key.replace('_', '-')}"
        command_flags.extend([key_flag, str(value)])
    command_args = command + [shlex.quote(str(a)) for a in args + tuple(command_flags)]

    full_command = " ".join(command_args)
    if mutex.is_locked(command_hash):
        return {
            "command": {
                "arguments": command_args,
                "base": command,
                "hash": command_hash,

            },
            "pid": mutex.get_pid(command_hash),
            "state": "RUNNING",
        }



    process = await asyncio.create_subprocess_shell(
        full_command,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE,
    )
    pid = process.pid

    locked = mutex.lock(command, pid)
    if not locked:
        return {
            "command": {
                "arguments": command_args,
                "base": command,
                "hash": command_hash
            },
            "pid": mutex.get_pid(command_hash),
            "state": "RUNNING",
        }

    try:
        stdout, stderr = await process.communicate()
        if not stderr:
            return {
                "command": {
                    "arguments": command_args,
                    "base": command,
                    "hash": command_hash
                },
                "message": f"{stdout}",
                "pid": mutex.get_pid(command_hash),
                "state": "COMPLETED"
            }
        else:
            return {
                "command": {
                    "arguments": command_args,
                    "base": command,
                    "hash": command_hash
                },
                "message": f"{stderr}",
                "pid": mutex.get_pid(command_hash),
                "state": "FAILED"
            }
    except Exception as e:
        return {
            "command": {
                "arguments": command_args,
                "base": command,
                "hash": command_hash
            },
            "message": f"{type(e).__name__}: {e}",
            "pid": mutex.get_pid(command_hash),
            "state": "FAILED"
        }
    finally:
        mutex.unlock(command_hash)


@dataclass
class BaseCommand(ABC):

    #  cmd = RestoreCommand(executable="serverc.exe")
    #  cmd = BackupCommand(executable="capellac.exe")

    executable: str
    vm_args: List[str] = field(default_factory=list)
    java_version: str = "17"
    min_heap: str = '1000m',
    max_heap: str = '3000m',

    @abstractmethod
    def get_args(self) -> List[str]:
        ...

    @abstractmethod
    def get_params(self) -> List[str]:
        ...

    def build_full_command(self) -> str:
        base_args = self.get_args()
        vm_args = self.vm_args + [
            f"-Xms{self.min_heap}",
            f"-Xmx{self.max_heap}",
            f"-Dosgi.requiredJavaVersion={self.java_version}"
        ]
        params = self.get_params()
        return " ".join([self.executable] + base_args + ["-vmargs"] + vm_args + params)


@dataclass
class RestoreBaseCommand(BaseCommand):
    ini_file: str = "server.ini"
    restore: bool = True
    restore_folder: str = "./restore"
    rename_source: bool = False
    config_dir: str = "configuration"


    def get_args(self) -> List[str]:
        return [
            f"--launcher.ini {self.ini_file}"
        ]

    @abstractmethod
    def get_params(self) -> List[str]:
        ...

    def __post_init__(self):
        self.vm_args.extend([
            "-XX:+UseG1GC",
            "-XX:+UseStringDeduplication",
            f"-Dcollab.db.restore={str(self.restore).lower()}",
            f"-Dcollab.db.restoreFolder=\"{self.restore_folder}\"",
            f"-Dcollab.db.restore.rename.source.file={str(self.rename_source).lower()}",
            f"-Dnet4j.config={self.config_dir}",
            "-Dnet4j.security.FileUserManager.fallBackToConfigFolder=true",
            "-Dcom.thalesgroup.mde.capella.team.close.server.after.initialization=true"
        ])

@dataclass
class HttpClientBaseCommand(BaseCommand):
    workspace_path: str = field(default_factory=str)
    http_host: str = 'localhost'
    http_port: int = 8080
    https_connection: bool = False
    stack_size: str = '4m',
    log_config_path: str = 'configuration/logback.xml'


    def get_args(self) -> List[str]:
        return [
            "--launcher.suppressErrors",
            "-nosplash",
            "-console", "-consoleLog",
            "-data", self.workspace_path,
            "-httpHost", self.http_host,
            "-httpPort", str(self.http_port),
            "-httpsConnection", str(self.https_connection).lower(),
        ]

    @abstractmethod
    def get_params(self) -> List[str]:
        ...

    def __post_init__(self):
        self.vm_args.extend([
            f"-Xss{self.stack_size}",
            "-XX:+UseG1GC",
            "-XX:+UseStringDeduplication",
            "-Dorg.eclipse.net4j.util.om.trace.disable=true",
            f"-Dosgi.requiredJavaVersion={self.java_version}",
            "-Dosgi.dataAreaRequiresExplicitInit=true",
            f"-Dlogback.configurationFile={self.log_config_path}",
            f"-Dpde.jreProfile=JavaSE-{self.java_version}"
        ])


@dataclass
class LicenceClientBaseCommand(BaseCommand):
    workspace_path: str = field(default_factory=str)
    stack_size: str = '4m',
    log_config_path: str = 'configuration/logback.xml'


    def get_args(self) -> List[str]:
        return [
            "--launcher.suppressErrors",
            "-nosplash",
            "-console", "-consoleLog",
            "-data", self.workspace_path,
        ]

    @abstractmethod
    def get_params(self) -> List[str]:
        ...

    def __post_init__(self):
        self.vm_args.extend([
            f"-Xss{self.stack_size}",
            "-XX:+UseG1GC",
            "-XX:+UseStringDeduplication",
            "-Dorg.eclipse.net4j.util.om.trace.disable=true",
            f"-Dosgi.requiredJavaVersion={self.java_version}",
            "-Dosgi.dataAreaRequiresExplicitInit=true",
            f"-Dlogback.configurationFile={self.log_config_path}",
            f"-Dpde.jreProfile=JavaSE-{self.java_version}"
        ])


@dataclass
class ImportBaseCommand(HttpClientBaseCommand):
    data_workspace: str = "importer-workspace",
    repository_credentials_path: str = "../tools/repositoryCredentials.properties"

    def get_args(self) -> List[str]:
        return super().get_args() + [
            "-data", self.data_workspace,
            "-application com.thalesgroup.mde.melody.collab.importer"
            "-repositoryCredentials", self.repository_credentials_path,
            "-checksize -1",
            "-closeserveronfailure false",
            "-stopRepositoryOnFailure false"
        ]

    @abstractmethod
    def get_params(self) -> List[str]:
        ...

    def __post_init__(self):
        super().__post_init__()
        self.vm_args.extend([
            "-Dfr.obeo.dsl.viewpoint.collab.import.gmf.notation.keep.cdoid.as.xmiid=true",
            "-Dfr.obeo.dsl.viewpoint.collab.import.other.elements.keep.cdoid.as.xmiid=true"
        ])

@dataclass
class MaintenanceBaseCommand(HttpClientBaseCommand):
    data_workspace: str = "maintenance-workspace"
    repository_credentials_path: str = "../tools/repositoryCredentials.properties"

    def get_args(self) -> List[str]:
        return super().get_args() + [
            "-data", self.data_workspace,
            "-application com.thalesgroup.mde.melody.collab.maintenance"
            "-repositoryCredentials", self.repository_credentials_path
        ]

    @abstractmethod
    def get_params(self) -> List[str]:
        ...


@dataclass
class ToolCredentialBaseCommand(LicenceClientBaseCommand):

    def get_args(self) -> List[str]:
        return super().get_args() + [
            "-application", "fr.obeo.dsl.viewpoint.collab.tools.credentials"
        ]

    @abstractmethod
    def get_params(self) -> List[str]:
        ...

@dataclass
class Restore(RestoreBaseCommand):

    def get_params(self) -> List[str]:
        return []

@dataclass
class Backup(HttpClientBaseCommand):

    def get_args(self) -> List[str]:
        return super().get_args() + [
            "-application", "fr.obeo.dsl.viewpoint.collab.tools.command",
        ]

    def get_params(self) -> List[str]:
        return [
            "-data", f"\"{self.workspace_path}/command-workspace\"",
            "-command capella_db",
            f"-commandParams backup, \"{self.workspace_path}\""
        ]

@dataclass
class MaintenanceRepository(MaintenanceBaseCommand):
    repository_name: str = field(default_factory=str)

    def get_params(self) -> List[str]:
        return [
            "-repoName",  self.repository_name,
            "-data", f"\"{self.workspace_path}/maintenance-workspace\"",
            "-diagnosticOnly false",
            "-launchBackup true",
            "-archiveFolder", f"\"{self.workspace_path}\""
        ]

@dataclass
class StoreCredentials(ToolCredentialBaseCommand):
    host_name: str = field(default_factory=str)
    host_port: int = field(default_factory=int)
    repository_name: str = field(default_factory=str)
    login: str = field(default_factory=str)
    password: str = field(default_factory=str)
    credential_type: CredentialType = CredentialType.TOOLS_HTTP_CREDENTIALS

    def get_params(self) -> List[str]:
        return [
            "-data", f"\"{self.workspace_path}/tools-workspace\"",
            "-credentialType", self.credential_type,
            "-hostname", self.host_name,
            "-port", str(self.host_port),
            "-reponame",  self.repository_name,
            "-userId", self.login,
            "-userPassword", self.password
        ]

@dataclass
class ToolsClearCredentials(ToolCredentialBaseCommand):
    host_name: str = field(default_factory=str)
    host_port: int = field(default_factory=int)
    repository_name: str = field(default_factory=str)
    login: str = field(default_factory=str)
    password: str = field(default_factory=str)
    credential_type: CredentialType = CredentialType.TOOLS_HTTP_CREDENTIALS

    def get_params(self) -> List[str]:
        return [
            "-data", f"\"{self.workspace_path}/tools-workspace\"",
            "-credentialType", self.credential_type,
            "-hostname", self.host_name,
            "-port", self.host_port,
            "-reponame", self.repository_name,
            "-clearStoredCredentials true"
        ]

@dataclass
class ImportProject(ImportBaseCommand):
    repository_name: str = field(default_factory=str)
    import_file_path: str = "./dump.xml"

    def get_params(self) -> List[str]:
        return [
            "-data", f"\"{self.workspace_path}/importer-workspace\"",
            "-archiveProject true",
            "-outputFolder", self.workspace_path,
            "-reponame", self.repository_name,
            "-stopRepositoryOnFailure true",
            "-checksize 5",
            "-checkSession true",
            "-importCommitHistoryAsText true",
            "-includeCommitHistoryChanges false",
            "-computeImpactedRepresentationsForCommitHistoryChanges false",
             "-importFilePath", f"\"{self.workspace_path}/{self.import_file_path}\"",
            "-cdoExport true",
             "-archiveCdoExportResult true"
        ]