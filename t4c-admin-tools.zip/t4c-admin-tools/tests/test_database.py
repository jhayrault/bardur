import asyncio
import random
import string
from pathlib import Path
from typing import List, Tuple
import unittest
import tempfile
import zipfile
import os
from unittest import mock

from t4c_admin_tools.application.database import list_all_previous_backup, remove_all_previous_backup, database_restore, \
    RestoreResult, database_backup, BackupResult
from tests.decorators.async_test import async_test
from tests.mocks.process import MockProcess


class TestBackupDatabase(unittest.TestCase):

    def setUp(self) -> None:
        self.zip_files: List[Path] = []
        self._temp_dirs: List[tempfile.TemporaryDirectory] = []

        backup_dir = tempfile.TemporaryDirectory()
        self.backup_path = Path(backup_dir.name)
        self._temp_dirs.append(backup_dir)

        rand_suffix = ''.join(random.choices(string.ascii_lowercase + string.digits, k=6))
        file_name = f"{rand_suffix}.sql"
        file_content = f"Random content {rand_suffix}"

        file_path = self.backup_path / file_name
        with open(file_path, 'w') as f:
            f.write(file_content)

        with tempfile.NamedTemporaryFile(suffix=".zip", delete=False) as temp_zip:
            zip_path = temp_zip.name

        with zipfile.ZipFile(zip_path, 'w') as zipf:
            zipf.write(file_path, arcname=file_name)

        self.zip_files.append(Path(zip_path))

    def tearDown(self) -> None:
        for zip_file in self.zip_files:
            if os.path.exists(zip_file):
                os.remove(zip_file)
        for temp_dir in self._temp_dirs:
            temp_dir.cleanup()

    @async_test
    async def test_backup_success(self) -> None:
        # ARRANGE
        proc = MockProcess(stdout=b"Success backup", stderr=b"", return_code=0)
        backup_folder = self.backup_path
        # ACT
        with mock.patch("asyncio.create_subprocess_shell", return_value=proc):
            act: BackupResult = await database_backup(backup_folder)
        # ASSERT
        self.assertEqual(act["output"]["state"], "COMPLETED")
        self.assertEqual(act["output"]["message"], "Success backup")

    @async_test
    async def test_backup_error(self) -> None:
        # ARRANGE
        proc = MockProcess(stdout=b"", stderr=b"Some error backup", return_code=1)
        backup_folder = self.backup_path
        # ACT
        with mock.patch("asyncio.create_subprocess_shell", return_value=proc):
            act: BackupResult = await database_backup(backup_folder)
        # ASSERT
        self.assertEqual(act["output"]["state"], "FAILED")
        self.assertEqual(act["output"]["message"], "Some error backup")

    @async_test
    async def test_backup_pending(self) -> None:
        # ARRANGE
        proc = MockProcess(hang=True)
        backup_folder = self.backup_path
        # ACT
        with mock.patch("asyncio.create_subprocess_shell", return_value=proc):
            act: Tuple[BackupResult, BackupResult] = await asyncio.gather(
                database_backup(backup_folder),
                database_backup(backup_folder)
            )
        # ASSERT
        self.assertEqual(act[1]["output"]["state"], "PENDING")

    @async_test
    async def test_remove_all_previous_backup(self) -> None:
        # ARRANGE
        zip_files = self.zip_files
        backup_path = self.backup_path
        # ACT
        await remove_all_previous_backup(zip_files)
        # ASSERT
        self.assertListEqual(os.listdir(backup_path), [], "")

    @async_test
    async def test_list_all_previous_backup(self) -> None:
        # ARRANGE
        zip_files = self.zip_files
        backup_path = self.backup_path
        # ACT
        act = await list_all_previous_backup(backup_path)
        # ASSERT
        self.assertListEqual(zip_files, act, "")


class TestRestoreDatabase(unittest.TestCase):

    def setUp(self) -> None:
        base_dir = tempfile.TemporaryDirectory()
        base_path = base_dir.name
        self.workspace_path = os.path.join(base_path, "workspace")
        self.restore_folder = os.path.join(base_path, "dump")
        os.makedirs(self.workspace_path)
        os.makedirs(self.restore_folder )
        for i in range(1, 4):
            file_path = os.path.join(self.restore_folder , f"dump-{i}.sql.zip")
            with open(file_path, "w") as f:
                f.write(f"-- SQL dump file {i} --\n")


    @async_test
    async def test_restore_success(self) -> None:
        # ARRANGE
        proc = MockProcess(stdout=b"Success restoration", stderr=b"", return_code=0)
        restore_folder = self.restore_folder
        # ACT
        with mock.patch("asyncio.create_subprocess_shell", return_value=proc):
            act: RestoreResult = await database_restore(restore_folder)
        # ASSERT
        self.assertEqual(act["output"]["state"], "COMPLETED")
        self.assertEqual(act["output"]["message"], "Success restoration")

    @async_test
    async def test_restore_error(self) -> None:
        # ARRANGE
        proc = MockProcess(stdout=b"", stderr=b"Some error test", return_code=1)
        restore_folder = self.restore_folder
        # ACT
        with mock.patch("asyncio.create_subprocess_shell", return_value=proc):
            act: RestoreResult = await database_restore(restore_folder)
        # ASSERT
        self.assertEqual(act["output"]["state"], "FAILED")
        self.assertEqual(act["output"]["message"], "Some error test")

    @async_test
    async def test_restore_pending(self) -> None:
        # ARRANGE
        proc = MockProcess(hang=True)
        restore_folder = self.restore_folder
        # ACT
        with mock.patch("asyncio.create_subprocess_shell", return_value=proc):
            act: Tuple[RestoreResult, RestoreResult] = await asyncio.gather(
                database_restore(restore_folder),
                database_restore(restore_folder)
            )
        # ASSERT
        self.assertEqual(act[1]["output"]["state"], "PENDING")
