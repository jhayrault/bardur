import unittest
from pathlib import Path
import tempfile
from unittest.mock import patch, MagicMock
from t4c_admin_tools.application.project import encode_repository_ref, delete_files_by_extension, delete_directory, project_import
from tests.decorators.async_test import async_test


class TestImportProject(unittest.TestCase):

    def setUp(self):
        self.temp_dir = tempfile.TemporaryDirectory()
        self.test_dir = Path(self.temp_dir.name)
        self.files = ['file.zip', 'log.txt', 'data.activitymetadata', 'meta.json', 'info.xml']
        for file_name in self.files:
            (self.test_dir / file_name).write_text("test")

        self.test_subdir = self.test_dir / 'importer-workspace'
        self.test_subdir.mkdir(exist_ok=True)

    def tearDown(self):
        self.temp_dir.cleanup()

    @async_test
    @patch('subprocess.run')
    async def test_import_project_success(self, mock_run: MagicMock) -> None:
        pass

    @async_test
    @patch('subprocess.run')
    async def test_import_project_error(self, mock_run: MagicMock) -> None:
        pass

    @async_test
    @patch('subprocess.run')
    async def test_import_project_pending(self, mock_run: MagicMock) -> None:
        pass

    def test_delete_files_by_extension(self):
        # ARRANGE
        test_dir = self.test_dir
        # ACT
        delete_files_by_extension(test_dir)
        # ASSERT
        remaining_files = list(test_dir.glob('*'))
        self.assertEqual(
            len(remaining_files),
            1,
            "Only the subdirectory should remain"
        )
        self.assertTrue(
            test_dir in remaining_files,
            "The importer workspace directory should remain after deletion"
        )

    def test_remove_directory(self):
        # ARRANGE
        test_dir = self.test_dir
        # ACT
        delete_directory(test_dir)
        # ASSERT
        self.assertFalse(self.test_subdir.exists())

    @patch('importer_script.subprocess.run')
    def test_run_importer_script(self, mock_run):
        # ARRANGE
        mock_run.return_value = MagicMock()
        workspace = self.test_dir
        # ACT
        project_import(workspace)
        # ASSERT
        mock_run.assert_called_once()
        call_args = mock_run.call_args[0][0]
        self.assertIn('-data',  call_args)
        self.assertIn('-importFilePath',  call_args)


class TestListProject(unittest.TestCase):

    @patch('importer_script.subprocess.run')
    def test_run_command_script(self, mock_run):
        mock_run.return_value = MagicMock()
        tools_path = self.test_dir
        workspace = self.test_dir
        capella_home = self.test_dir
        repo_name = "repoX"
        timestamp = "2024-03-04 12:34:56"
        run_command_script(tools_path, workspace, capella_home, repo_name, timestamp)
        mock_run.assert_called_once()
        called_args = mock_run.call_args[0][0]
        self.assertIn('-httpRequestPath', called_args)
        self.assertIn('checkout=2024-03-04+12%3A34%3A56', called_args[-1])

    def test_head_cases(self):
        self.assertEqual(encode_repository_ref(None), "head")
        self.assertEqual(encode_repository_ref(""), "head")
        self.assertEqual(encode_repository_ref("head"), "head")
        self.assertEqual(encode_repository_ref("HEAD"), "head")
        self.assertEqual(encode_repository_ref("  head  "), "head", "trimmed input")

    def test_valid_timestamp_encoding(self):
        self.assertEqual(
            encode_repository_ref("2024-05-23T14:15:30.123Z"),
            "2024-05-23T14%3A15%3A30.123Z"
        )
        self.assertEqual(
            encode_repository_ref("1999-12-31T23:59:59.999Z"),
            "1999-12-31T23%3A59%3A59.999Z"
        )

    def test_invalid_format_raises(self):
        with self.assertRaises(ValueError):
            encode_repository_ref("2024-05-23 14:15:30")
        with self.assertRaises(ValueError):
            encode_repository_ref("2024-05-23T14:15:30Z")
        with self.assertRaises(ValueError):
            encode_repository_ref("head123")
        with self.assertRaises(ValueError):
            encode_repository_ref("2024-05-23T14:15:30.12Z")
